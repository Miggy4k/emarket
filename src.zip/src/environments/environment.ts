// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  appname:"eMarket",
  firebaseConfig :{
    apiKey: "AIzaSyDBhI1Em6i2i35taLgVKeBAWpKXWFA51S0",
  authDomain: "ecom-214dc.firebaseapp.com",
  projectId: "ecom-214dc",
  storageBucket: "ecom-214dc.appspot.com",
  messagingSenderId: "681951067357",
  appId: "1:681951067357:web:07189b088446fd02b1af34",
  databaseURL: "https://ecom-214dc-default-rtdb.asia-southeast1.firebasedatabase.app",
 serverKey:"AAAAnsdzfN0:APA91bGx4mFFc06YcY8K3Ynzd_KwTgCCG7d6NBRyGyxVmhYorghxy0HupgU8ppUJGIXPPfbm8DE_jLVxTsaoBbKg86SbTNCerkdAbpYb-huMBGhOgONkFbzvLbahBulqcH08xTdklIwj",
 senderId:"681951067357"
    
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
