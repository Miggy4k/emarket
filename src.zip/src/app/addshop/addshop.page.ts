import { Component, OnInit } from '@angular/core';
import {ApisService } from "../apis.service";

@Component({
  selector: 'app-addshop',
  templateUrl: './addshop.page.html',
  styleUrls: ['./addshop.page.scss'],
})
export class AddshopPage implements OnInit {
  shopObj:any={imgPath:"",shopName:"",shopDescription:"",category:"",location:""}
  constructor(private api:ApisService) { }

  ngOnInit() {
  }

  uploadImage()
  {
    let ref = this;
    if (this.shopObj.base64)
    {
      this.api.upload(this.shopObj.base64, Date.now().toString() + ".png", function (url:string)
      {
        if (url)
        {
          ref.shopObj.imgPath = url;
          ref.api.insertOrder(ref.shopObj, Date.now().toString(), function ()
          {
            
          })
         }
      })
      }
  }

}
