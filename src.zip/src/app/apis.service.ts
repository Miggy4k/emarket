import { Injectable } from '@angular/core';
import firebase from 'firebase';
import { environment } from "../environments/environment";
import { Platform, LoadingController, ToastController, AlertController } from "@ionic/angular";
import { Storage } from "@ionic/storage";

@Injectable({
  providedIn: 'root'
})
export class ApisService {
config: any = environment.firebaseConfig;
  appname: any = environment.appname;
  email: string = "";
  role: string = "";
  token:any={};
  constructor(private platform: Platform,private storage:Storage,private loader:LoadingController,private toast:ToastController) { 
     this.platform.ready().then(() => {
     
      if (firebase.apps.length == 0) {
        firebase.initializeApp(this.config);

      }
      this.storage.get("token").then((token) => {
        this.token = token;
        this.email = "niks9489@gmail.com";
        this.token = "admin";
      })

    })
  }

  //shop insertion

   insertOrder(obj:any,  key:any, fn:any) {
    this.loader.create({
      message: "please wait..."
    }).then((ele) => {

      ele.present();
      
      firebase.database().ref(this.appname + "/orders/" + this.email.replace(/[^\w\s]/gi, '') + "/" + key).set(obj).then(() => {
        ele.dismiss();


        fn("ok");
        this.showToast("successfully inserted!");


      }, (err) => {
        ele.dismiss();
        this.showToast(JSON.stringify(err));

      })
    })
   }
  
  showToast(msg:any) {

    this.toast.create({
      message: msg,
      duration: 3000,
      


    }).then((ele) => {
      ele.present();
    })
  }

  upload(base64:any, fileName:any, fn:any) {
    let ref = this;
    this.loader.create({
      message: "uploading file..."
    }).then((ele) => {

      ele.present();

      // window.app.firebasetemp.database().ref(window.app.appName+"/images/"+id+"/").set(obj, function (err) {

      //   ele.dismiss();
      // })
      var storageref = firebase.storage().ref();

      var childRef = storageref.child(fileName);
      childRef.putString(base64, "data_url").then((snapshot) => {
        ele.dismiss();
        snapshot.ref.getDownloadURL().then((downloadURL) => {

          fn(downloadURL)
        }, (err) => {
          ele.dismiss();
          console.log(err);
        });
      }, (err) => {
        ele.dismiss();
        console.log(err);
      })


    })
  }

}
